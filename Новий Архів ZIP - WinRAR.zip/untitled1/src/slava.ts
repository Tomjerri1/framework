let myString: string = "Hello, TypeScript!";
let myNumber: number = 42;
let myBoolean: boolean = true;
let myAny: any = "This can be anything!";

console.log(myString);
console.log(myNumber);
console.log(myBoolean);
console.log(myAny);
