let stringArray: string[] = ["apple", "banana", "cherry"];
let numberArray: number[] = [1, 2, 3, 4, 5];

console.log(stringArray);
console.log(numberArray);
